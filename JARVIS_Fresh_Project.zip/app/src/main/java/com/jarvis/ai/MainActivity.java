package com.jarvis.ai;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  LinearLayout page = new LinearLayout(this);
  page.setOrientation(LinearLayout.VERTICAL);
  page.setGravity(Gravity.CENTER_HORIZONTAL);
  page.setPadding(24,40,24,24);
  page.setBackgroundColor(Color.rgb(8,16,32));
  TextView title = new TextView(this);
  title.setText("JARVIS");
  title.setTextColor(Color.WHITE);
  title.setTextSize(34);
  title.setGravity(Gravity.CENTER);
  page.addView(title, new LinearLayout.LayoutParams(-1,80));
  TextView intro = new TextView(this);
  intro.setText("नमस्ते! मैं JARVIS हूँ। आपका personal AI assistant.");
  intro.setTextColor(Color.LTGRAY);
  intro.setTextSize(18);
  intro.setGravity(Gravity.CENTER);
  page.addView(intro, new LinearLayout.LayoutParams(-1,90));
  Button youtube = new Button(this);
  youtube.setText("YouTube खोलें");
  youtube.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))));
  page.addView(youtube, new LinearLayout.LayoutParams(-1,58));
  TextView note = new TextView(this);
  note.setText("यह शुरुआती प्रोजेक्ट है। Gemini chat, voice और screen control अभी शामिल नहीं हैं; इन्हें आगे जोड़ेंगे।");
  note.setTextColor(Color.GRAY);
  note.setGravity(Gravity.CENTER);
  note.setPadding(8,24,8,8);
  page.addView(note);
  setContentView(page);
 }
}
