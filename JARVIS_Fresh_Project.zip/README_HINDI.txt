JARVIS AI - Fresh Starter Project

इस शुरुआती ऐप में JARVIS की basic screen और YouTube shortcut है।
Gemini AI chat, voice assistant, wake word और screen/app control अभी शामिल नहीं हैं।

ZIP को extract करके इसके अंदर की सभी फाइलें (छिपे हुए .github फोल्डर सहित) GitHub repository की main branch में upload करें।
फिर GitHub > Actions > Build JARVIS APK > Run workflow करें।
Build पूरा होने पर Artifacts में JARVIS-debug-APK डाउनलोड करें।

यह ZIP APK नहीं है; APK ऑनलाइन build होगी।
